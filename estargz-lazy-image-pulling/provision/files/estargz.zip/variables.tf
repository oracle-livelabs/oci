# Copyright (c) 2024, 2026, Oracle and/or its affiliates. All rights reserved.
# The Universal Permissive License (UPL), Version 1.0 as shown at https://oss.oracle.com/licenses/upl/

variable "provider_oci" {
  type = map(string)
}

variable "compartment_ids" {
  type = map(string)
}

########################### NETWORK #################################

variable "vcn_params" {
  description = "VCN Parameters: vcn_cidr, display_name, dns_label"
  type = map(object({
    vcn_cidr         = string
    compartment_name = string
    display_name     = string
    dns_label        = string
  }))
}

variable "igw_params" {
  description = "Placeholder for vcn index association and igw name"
  type = map(object({
    vcn_name     = string
    display_name = string
  }))
}

variable "ngw_params" {
  description = "Placeholder for vcn index association and ngw name"
  type = map(object({
    vcn_name     = string
    display_name = string
  }))
}

variable "rt_params" {
  description = "Placeholder for vcn index association, rt name, route rules"
  type = map(object({
    vcn_name     = string
    display_name = string
    route_rules = list(object({
      destination = string
      use_igw     = bool
      igw_name    = string
      ngw_name    = string
    }))
  }))
}

variable "sl_params" {
  description = "Security List Params"
  type = map(object({
    vcn_name     = string
    display_name = string
    egress_rules = list(object({
      stateless   = string
      protocol    = string
      destination = string
    }))
    ingress_rules = list(object({
      stateless   = string
      protocol    = string
      source      = string
      source_type = string
      tcp_options = list(object({
        min = number
        max = number
      }))
      udp_options = list(object({
        min = number
        max = number
      }))
    }))
  }))
}


variable "subnet_params" {
  type = map(object({
    display_name      = string
    cidr_block        = string
    dns_label         = string
    is_subnet_private = bool
    sl_name           = string
    rt_name           = string
    vcn_name          = string
  }))
}
############################## COMPUTE ##################################

variable "linux_images" {
  type = map(map(string))
}

variable "instance_params" {
  description = "Placeholder for the parameters of the instances"
  type = map(object({
    ad                   = number
    shape                = string
    hostname             = string
    boot_volume_size     = number
    assign_public_ip     = bool
    preserve_boot_volume = bool
    compartment_name     = string
    subnet_name          = string
    freeform_tags        = map(string)
    block_vol_att_type   = string
    encrypt_in_transit   = bool
    fd                   = optional(number)
    image_version        = string
    ssh_private_key      = string
    script_tf_string     = string
    ocpus                = optional(number)
    memory_in_gbs        = optional(number)
  }))
}

variable "ssh_public_key" {
  type = string
}

variable "kms_key_ids" {
  type = map(string)
}

variable "registry" {
  type = string
  validation {
    condition     = can(regex("^[a-z]{3}\\.ocir\\.io$", var.registry))
    error_message = "Registry must look like fra.ocir.io or iad.ocir.io."
  }
}

variable "estargz_image" {
  description = "Optional eStargz image reference used by the VM benchmark helper."
  type        = string
  default     = ""
}

variable "regular_image" {
  description = "Optional regular image reference used as the overlayfs benchmark baseline."
  type        = string
  default     = ""
}

variable "run_validation" {
  description = "Run the benchmark once from cloud-init when image inputs are provided."
  type        = bool
  default     = false
}
