import json
import unittest
from types import SimpleNamespace
from unittest.mock import patch

import llm


class FakeResponses:
    def __init__(self, responses):
        self.responses = list(responses)
        self.created_options = []

    def create(self, **kwargs):
        self.created_options.append(kwargs)
        return self.responses.pop(0)


class FakeClient:
    def __init__(self, responses):
        self.responses = responses


def function_call_response():
    return SimpleNamespace(
        id="resp_1",
        status="completed",
        output=[
            SimpleNamespace(
                type="function_call",
                name=llm.SQL_TOOL_NAME,
                call_id="call_1",
                arguments=json.dumps({"question": "Show open service appointments"}),
            )
        ],
    )


def text_response(text):
    return SimpleNamespace(
        id="resp_2",
        status="completed",
        output_text=text,
        output=[SimpleNamespace(content=[SimpleNamespace(text=text)])],
    )


class ToolLoopTests(unittest.TestCase):
    def setUp(self):
        self.cfg = {"max_output_tokens": 1000}
        self.original_sleep = llm.time.sleep
        llm.time.sleep = lambda _seconds: None

    def tearDown(self):
        llm.time.sleep = self.original_sleep

    def test_stream_response_submits_sql_tool_output(self):
        responses = FakeResponses(
            [
                function_call_response(),
                text_response("There is one open appointment."),
            ]
        )
        client = FakeClient(responses)
        tool_result = {
            "status": "ok",
            "columns": ["appointment_id"],
            "rows": [{"appointment_id": 123}],
            "truncated": False,
        }

        with patch("llm.query_database", return_value=tool_result) as query_database:
            chunks = list(llm.stream_response(client, "model", "question", self.cfg))

        query_database.assert_called_once_with("Show open service appointments", self.cfg)
        self.assertEqual(chunks[-1], "There is one open appointment.")
        self.assertEqual(len(responses.created_options), 2)
        second_input = responses.created_options[1]["input"]
        self.assertEqual(
            second_input[0],
            {"role": "user", "content": "question"},
        )
        self.assertEqual(second_input[1]["role"], "user")
        self.assertIn("Tool call call_1 output", second_input[1]["content"])
        self.assertIn(json.dumps(tool_result), second_input[1]["content"])
        self.assertNotIn("previous_response_id", responses.created_options[1])

    def test_stream_response_reports_progress_statuses(self):
        responses = FakeResponses(
            [
                function_call_response(),
                text_response("There is one open appointment."),
            ]
        )
        client = FakeClient(responses)
        statuses = []
        tool_result = {
            "status": "ok",
            "columns": ["appointment_id"],
            "rows": [{"appointment_id": 123}],
            "truncated": False,
        }

        with patch("llm.query_database", return_value=tool_result):
            list(
                llm.stream_response(
                    client,
                    "model",
                    "question",
                    self.cfg,
                    status_callback=statuses.append,
                )
            )

        self.assertEqual(
            statuses,
            [
                "Sending prompt to LLM (model)...",
                "Received response from LLM (model).",
                "Calling SQL retrieval tool...",
                "Sending retrieved data back to LLM (model)...",
                "Received response from LLM (model).",
                "Received final response from LLM (model).",
            ],
        )


if __name__ == "__main__":
    unittest.main()
