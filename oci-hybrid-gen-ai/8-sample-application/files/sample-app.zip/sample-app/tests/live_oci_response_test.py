import re
import unittest

import llm


PROMPT = "How do I check tire pressure on my car?"
MIN_WORDS = 40
MIN_CHARS = 200


class LiveOciResponseTest(unittest.TestCase):
    def test_llm_prompt_returns_at_least_a_paragraph(self):
        cfg = llm.settings()
        missing = [name for name in ("region", "project_ocid", "model") if not cfg[name]]
        if missing:
            self.fail("Missing configuration: " + ", ".join(missing))

        client = llm.make_client(
            cfg["region"],
            cfg["project_ocid"],
            cfg["oci_config_file"],
            cfg["oci_config_profile"],
        )

        chunks = list(llm.stream_response(client, cfg["model"], PROMPT, cfg))
        self.assertTrue(chunks, "No response chunks were returned.")

        answer = chunks[-1].strip()
        words = re.findall(r"\b\w+\b", answer)
        self.assertGreaterEqual(
            len(words),
            MIN_WORDS,
            f"Response was too short ({len(words)} words): {answer!r}",
        )
        self.assertGreaterEqual(
            len(answer),
            MIN_CHARS,
            f"Response was too short ({len(answer)} chars): {answer!r}",
        )


if __name__ == "__main__":
    unittest.main()
