import unittest
from types import SimpleNamespace

import llm


class FakeResponses:
    def __init__(self, created_response=None):
        self.created_response = created_response
        self.created_options = None

    def create(self, **kwargs):
        self.created_options = kwargs
        return self.created_response


class FakeClient:
    def __init__(self, responses):
        self.responses = responses


def response(text, output_text="", status="completed"):
    return SimpleNamespace(
        status=status,
        output_text=output_text,
        output=[SimpleNamespace(content=[SimpleNamespace(text=text)])],
    )


class StreamingTests(unittest.TestCase):
    def setUp(self):
        self.cfg = {"max_output_tokens": 1000}
        self.original_sleep = llm.time.sleep
        llm.time.sleep = lambda _seconds: None

    def tearDown(self):
        llm.time.sleep = self.original_sleep

    def test_response_text_prefers_full_output_over_short_output_text(self):
        text = llm.response_text(
            response(
                "The acronym LLM stands for large language model.",
                output_text="The acronym",
            )
        )

        self.assertEqual(text, "The acronym LLM stands for large language model.")

    def test_stream_response_uses_full_response_text(self):
        responses = FakeResponses(
            created_response=response(
                "The acronym LLM stands for large language model.",
                output_text="The acronym",
            )
        )
        client = FakeClient(responses)

        chunks = list(llm.stream_response(client, "model", "what is an LLM?", self.cfg))

        self.assertEqual(chunks[-1], "The acronym LLM stands for large language model.")

    def test_response_options_use_local_history_without_conversation(self):
        messages = [
            {"role": "user", "content": "What is a LLM?"},
            {"role": "assistant", "content": "A LLM is a large language model."},
            {"role": "error", "content": "Error messages are not sent back."},
        ]

        options = llm.response_options("model", "Can you expand?", self.cfg, messages)

        self.assertNotIn("conversation", options)
        self.assertEqual(options["instructions"], llm.CUSTOMER_SUPPORT_SYSTEM_PROMPT)
        self.assertNotIn(
            {"role": "system", "content": llm.CUSTOMER_SUPPORT_SYSTEM_PROMPT},
            options["input"],
        )
        self.assertEqual(
            options["input"],
            [
                {"role": "user", "content": "What is a LLM?"},
                {"role": "assistant", "content": "A LLM is a large language model."},
                {"role": "user", "content": "Can you expand?"},
            ],
        )

    def test_response_input_formats_attached_image_parts(self):
        messages = [
            {
                "role": "user",
                "content": "What is shown in this image?",
                "images": [
                    {
                        "filename": "photo.png",
                        "mime_type": "image/png",
                        "size": 1234,
                        "data_url": "data:image/png;base64,aW1hZ2U=",
                    }
                ],
            }
        ]

        response_input = llm.response_input(messages, "What is shown in this image?")

        self.assertEqual(
            response_input,
            [
                {
                    "role": "user",
                    "content": [
                        {"type": "input_text", "text": "What is shown in this image?"},
                        {
                            "type": "input_image",
                            "image_url": "data:image/png;base64,aW1hZ2U=",
                        },
                    ],
                }
            ],
        )

    def test_response_input_keeps_prior_image_for_followup(self):
        messages = [
            {
                "role": "user",
                "content": "What is shown in this image?",
                "images": [
                    {
                        "filename": "photo.png",
                        "mime_type": "image/png",
                        "size": 1234,
                        "data_url": "data:image/png;base64,aW1hZ2U=",
                    }
                ],
            },
            {"role": "assistant", "content": "It shows a dashboard warning light."},
            {"role": "user", "content": "What should I check first?"},
        ]

        response_input = llm.response_input(
            messages,
            "What should I check first?",
        )

        self.assertEqual(
            response_input[0]["content"],
            [
                {"type": "input_text", "text": "What is shown in this image?"},
                {
                    "type": "input_image",
                    "image_url": "data:image/png;base64,aW1hZ2U=",
                },
            ],
        )
        self.assertEqual(
            response_input[-1],
            {"role": "user", "content": "What should I check first?"},
        )

    def test_response_options_reject_known_text_only_model_with_images(self):
        messages = [
            {
                "role": "user",
                "content": "What is shown?",
                "images": [{"data_url": "data:image/png;base64,aW1hZ2U="}],
            }
        ]

        with self.assertRaisesRegex(ValueError, "does not support image input"):
            llm.response_options("openai.gpt-oss-120b", "What is shown?", self.cfg, messages)


if __name__ == "__main__":
    unittest.main()
