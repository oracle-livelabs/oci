import logging
import json
import os
import time
from pathlib import Path

import httpx
from dotenv import load_dotenv
from oci_genai_auth import OciUserPrincipalAuth
from openai import OpenAI

from oci_iam_auth import DEFAULT_OCI_CONFIG_FILE, DEFAULT_OCI_CONFIG_PROFILE
from response_content import messages_include_images, response_input
from semantic_sql_tool import query_database


APP_DIR = Path(__file__).parent
load_dotenv(APP_DIR / ".env")

logger = logging.getLogger("oci-llm-chat")
DEFAULT_MAX_OUTPUT_TOKENS = 10000
DEFAULT_SQL_MAX_ROWS = 50
DEFAULT_SQL_TIMEOUT_SECONDS = 30
SQL_TOOL_NAME = "query_vehicle_database"
MAX_TOOL_ROUNDS = 3
KNOWN_TEXT_ONLY_IMAGE_MODELS = {"openai.gpt-oss-120b"}
CUSTOMER_SUPPORT_SYSTEM_PROMPT = (
    "You are a customer support agent for customers of a large auto manufacturer called Example Motors. "
    "Answer only questions about the manufacturer's cars, vehicle features, "
    "vehicle operation, maintenance, service appointments, and work performed on "
    "a customer's car. When the user attaches an image, use the attached image as "
    "the source for questions about that image's contents. Use available tools "
    "when they can help answer supported "
    "questions. Use the file_search tool for vehicle owner manual, entertainment/infortainment system "
    "questions, vehicle operation, "
    "feature usage, dashboard warning, troubleshooting, and maintenance procedure "
    "questions. Use query_vehicle_database only for current-customer database "
    "records, including the customer's profile, owned vehicles, service "
    "appointments, service history, work orders, repairs, and account data. Use "
    "database tool results as the only source for database-backed facts. If the "
    "database tool returns not_answerable, no_rows, or an error status, say the "
    "database did not contain enough information to answer. If no information is "
    "found through tools, say you do not have information about this particular "
    "question. Refusal and unavailable-information responses must be terse. Say "
    "only that you cannot help with that request or do not have enough "
    "information. Do not add generic customer-service advice, phone numbers, "
    "dealership referrals, policy explanations, or suggested next steps unless "
    "they are directly supported by retrieved tool results. "
    "If the user asks about anything outside this scope, refuse "
    "briefly and say you can only help with questions about the manufacturer's "
    "vehicles and customer service."
)
CUSTOMER_CONTEXT_PROMPT = (
    "\n\nSession customer context:\n"
    "- The current authenticated customer_id is {customer_id}.\n"
    "- Treat this as the only customer for this chat session.\n"
    "- For any question about the current customer, their vehicle records, service "
    "appointments, work orders, or account data, scope every retrieval and "
    "database query to customer_id = {customer_id}.\n"
    "- Do not retrieve or disclose another customer's records. If the user asks "
    "for another customer's private information, say you can only help with the "
    "current customer's records."
)


def env(name, default=""):
    return os.getenv(name, default).strip()


def int_env(name, default):
    try:
        return int(env(name, str(default)))
    except ValueError:
        logger.warning("Invalid integer for %s; using %s", name, default)
        return default


def list_env(name, default=None):
    raw = env(name)
    if not raw:
        return list(default or [])
    return [item.strip() for item in raw.split(",") if item.strip()]


def settings():
    region = env("OCI_GENAI_REGION")
    adb_mcp_region = env("OCI_ADB_MCP_REGION")
    return {
        "region": region,
        "project_ocid": env("OCI_GENAI_PROJECT_OCID", env("OCI_GENAI_PROJECT_ID")),
        "model": env("OCI_GENAI_MODEL"),
        "cheaper_model": env("OCI_GENAI_CHEAPER_MODEL"),
        "oci_config_file": env("OCI_CONFIG_FILE", DEFAULT_OCI_CONFIG_FILE),
        "oci_config_profile": env("OCI_CONFIG_PROFILE", DEFAULT_OCI_CONFIG_PROFILE),
        "max_output_tokens": int_env("OCI_GENAI_MAX_OUTPUT_TOKENS", DEFAULT_MAX_OUTPUT_TOKENS),
        "vector_store_ids": list_env("OCI_GENAI_VECTOR_STORE_IDS"),
        "semantic_store_ocid": env("OCI_GENAI_SEMANTIC_STORE_OCID"),
        "nl2sql_region": env("OCI_GENAI_NL2SQL_REGION", region),
        "nl2sql_api_version": env("OCI_GENAI_NL2SQL_API_VERSION", "20260325"),
        "adb_mcp_region": adb_mcp_region,
        "adb_database_ocid": env("OCI_ADB_DATABASE_OCID"),
        "adb_mcp_username": env("OCI_ADB_MCP_USERNAME"),
        "adb_mcp_password": env("OCI_ADB_MCP_PASSWORD"),
        "adb_mcp_password_secret_ocid": env("OCI_ADB_MCP_PASSWORD_SECRET_OCID"),
        "adb_mcp_password_secret_region": env(
            "OCI_ADB_MCP_PASSWORD_SECRET_REGION",
            adb_mcp_region,
        ),
        "adb_mcp_execute_tool": env("OCI_ADB_MCP_EXECUTE_TOOL", "EXECUTE_SQL"),
        "adb_mcp_sql_argument": env("OCI_ADB_MCP_SQL_ARGUMENT", "query"),
        "adb_mcp_offset_argument": env("OCI_ADB_MCP_OFFSET_ARGUMENT", "offset"),
        "adb_mcp_limit_argument": env("OCI_ADB_MCP_LIMIT_ARGUMENT", "limit"),
        "sql_max_rows": int_env("OCI_SQL_MAX_ROWS", DEFAULT_SQL_MAX_ROWS),
        "sql_timeout_seconds": int_env("OCI_SQL_TIMEOUT_SECONDS", DEFAULT_SQL_TIMEOUT_SECONDS),
    }


def make_client(region, project_ocid, config_file, config_profile):
    base_url = f"https://inference.generativeai.{region}.oci.oraclecloud.com/openai/v1"
    options = {
        "base_url": base_url,
        "project": project_ocid,
        "http_client": httpx.Client(
            auth=OciUserPrincipalAuth(
                config_file=config_file,
                profile_name=config_profile,
            ),
        ),
    }
    options["api" + "_" + "key"] = "not-used"
    return OpenAI(**options)


def response_text(response):
    text = value(response, "output_text", "") or ""
    output_text = "".join(text_from_item(item) for item in value(response, "output", []) or [])
    return output_text if len(output_text) > len(text) else text


def text_from_item(item):
    chunks = []
    direct_text = value(item, "text", "") or ""
    if direct_text:
        chunks.append(direct_text)

    for part in value(item, "content", []) or []:
        chunks.append(value(part, "text", "") or "")
    return "".join(chunks)


def value(item, name, default=None):
    if isinstance(item, dict):
        return item.get(name, default)
    return getattr(item, name, default)


def response_options(model, prompt, cfg, messages=None):
    model = response_model(model, cfg, messages)
    ensure_model_supports_images(model, messages)
    options = {
        "model": model,
        "instructions": response_instructions(cfg),
        "input": response_input(messages, prompt),
        "tools": response_tools(cfg),
    }
    if cfg["max_output_tokens"] > 0:
        options["max_output_tokens"] = cfg["max_output_tokens"]

    return options


def response_model(model, cfg, messages=None):
    # Uncomment to route image prompts to a stronger vision model and text-only
    # prompts to a cheaper text model.
    #if not messages_include_images(messages):
    #    model = cfg["cheaper_model"]

    return model


def ensure_model_supports_images(model, messages=None):
    normalized_model = (model or "").strip().lower()
    if messages_include_images(messages) and normalized_model in KNOWN_TEXT_ONLY_IMAGE_MODELS:
        raise ValueError(
            f"Configured model {model!r} does not support image input. "
            "Set OCI_GENAI_MODEL to a vision-capable model such as "
            "xai.grok-4"
        )


def response_instructions(cfg):
    customer_id = cfg.get("customer_id")
    if customer_id in (None, ""):
        return CUSTOMER_SUPPORT_SYSTEM_PROMPT
    return CUSTOMER_SUPPORT_SYSTEM_PROMPT + CUSTOMER_CONTEXT_PROMPT.format(
        customer_id=customer_id,
    )


def response_tools(cfg):
    tools = [sql_tool_definition(cfg.get("customer_id"))]
    vector_store_ids = cfg.get("vector_store_ids") or []
    if vector_store_ids:
        tools.append(
            {
                "type": "file_search",
                "vector_store_ids": vector_store_ids
            }
        )
    return tools


def sql_tool_definition(customer_id=None):
    description = (
        "Query customer-specific account and service records. Use only for facts "
        "about the current customer's profile, owned vehicle records, service "
        "appointments, service history, work orders, repairs, warranties, recalls, "
        "or account data. Do not use for owner manual, vehicle operation, feature "
        "usage, phone pairing, infotainment, troubleshooting, or maintenance "
        "procedure questions."
    )
    if customer_id not in (None, ""):
        description += (
            f" Customer-specific database access is scoped to current "
            f"customer_id {customer_id}."
        )

    return {
        "type": "function",
        "name": SQL_TOOL_NAME,
        "description": description,
        "parameters": {
            "type": "object",
            "required": ["question"],
            "properties": {
                "question": {
                    "type": "string",
                    "description": "The user's database-backed question.",
                }
            },
            "additionalProperties": False,
        },
    }


def stream_response(client, model, prompt, cfg, messages=None, status_callback=None):
    model = response_model(model, cfg, messages)
    model_label = model or "not configured"
    notify_status(status_callback, f"Sending prompt to LLM ({model_label})...")
    response = client.responses.create(**response_options(model, prompt, cfg, messages))
    notify_status(status_callback, f"Received response from LLM ({model_label}).")
    response = complete_tool_calls(
        client,
        response,
        model,
        cfg,
        prompt,
        messages,
        status_callback,
    )
    notify_status(status_callback, f"Received final response from LLM ({model_label}).")
    text = response_text(response)

    ensure_completed_response(response)

    if not text:
        logger.error("OCI completed response did not contain text: %s", response)
        raise RuntimeError("OCI completed the response without returning text.")

    for end in range(24, len(text) + 24, 24):
        yield text[:end]
        time.sleep(0.01)


def complete_tool_calls(
    client,
    response,
    model,
    cfg,
    prompt,
    messages=None,
    status_callback=None,
):
    followup_input = response_input(messages, prompt)
    for _round in range(MAX_TOOL_ROUNDS):
        ensure_completed_response(response)
        calls = sql_function_calls(response)
        if not calls:
            return response

        tool_outputs = [
            function_call_output(call, cfg, status_callback) for call in calls
        ]
        model_label = model or "not configured"
        notify_status(status_callback, f"Sending retrieved data back to LLM ({model_label})...")
        followup_input = followup_input + [
            {"role": "user", "content": tool_results_message(tool_outputs)}
        ]
        options = {
            "model": model,
            "instructions": response_instructions(cfg),
            "input": followup_input,
            "tools": response_tools(cfg),
        }
        if cfg["max_output_tokens"] > 0:
            options["max_output_tokens"] = cfg["max_output_tokens"]

        response = client.responses.create(**options)
        notify_status(status_callback, f"Received response from LLM ({model_label}).")

    raise RuntimeError("OCI response exceeded the maximum SQL tool-call rounds.")


def function_call_output(call, cfg, status_callback=None):
    if call["name"] != SQL_TOOL_NAME:
        result = {
            "status": "execution_error",
            "message": f"Unknown function call: {call['name']}",
            "columns": [],
            "rows": [],
            "truncated": False,
        }
    else:
        arguments = parse_arguments(call["arguments"])
        question = arguments.get("question") or arguments.get("query") or ""
        if not question:
            result = {
                "status": "execution_error",
                "message": "Missing required question argument.",
                "columns": [],
                "rows": [],
                "truncated": False,
            }
        else:
            notify_status(status_callback, "Calling SQL retrieval tool...")
            if status_callback:
                result = query_database(question, cfg, status_callback=status_callback)
            else:
                result = query_database(question, cfg)

    return {
        "type": "function_call_output",
        "call_id": call["call_id"],
        "output": json.dumps(result, default=str),
    }


def tool_results_message(tool_outputs):
    parts = [
        "The SQL retrieval tool returned the following data for the user's latest "
        "question. Use these results as the only source for database-backed facts "
        "and answer the user now."
    ]
    for output in tool_outputs:
        parts.append(
            f"Tool call {output['call_id']} output:\n```json\n{output['output']}\n```"
        )
    return "\n\n".join(parts)


def sql_function_calls(response):
    calls = []
    for item in value(response, "output", []) or []:
        item_type = value(item, "type")
        name = value(item, "name")
        if item_type != "function_call" or not name:
            continue
        calls.append(
            {
                "name": name,
                "call_id": value(item, "call_id") or value(item, "id"),
                "arguments": value(item, "arguments", "{}") or "{}",
            }
        )
    return calls


def parse_arguments(raw_arguments):
    if isinstance(raw_arguments, dict):
        return raw_arguments
    try:
        return json.loads(raw_arguments or "{}")
    except json.JSONDecodeError:
        return {}


def ensure_completed_response(response):
    if value(response, "status", "") != "completed":
        details = value(response, "incomplete_details")
        reason = value(details, "reason", "unknown")
        logger.error("OCI response did not complete (%s): %s", reason, response)
        raise RuntimeError(f"OCI response did not complete: {reason}")


def notify_status(status_callback, message):
    logger.info(message)
    if status_callback:
        status_callback(message)
