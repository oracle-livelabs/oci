def response_input(messages, prompt):
    history = []
    last_role = None
    last_content = None
    for message in messages or []:
        role = message.get("role")
        content = message.get("content", "")
        if role in {"user", "assistant"} and content:
            history.append({"role": role, "content": response_message_content(message)})
            last_role = role
            last_content = content

    if history and last_role == "user" and last_content == prompt:
        return history

    return history + [{"role": "user", "content": prompt}]


def response_message_content(message):
    content = message.get("content", "")
    images = message.get("images") or []
    if message.get("role") != "user" or not images:
        return content

    parts = [{"type": "input_text", "text": content}]
    for image_ref in images:
        image_url = value(image_ref, "data_url", "")
        if image_url:
            parts.append({"type": "input_image", "image_url": image_url})

    return parts if len(parts) > 1 else content


def messages_include_images(messages):
    return any(message.get("images") for message in messages or [])


def value(item, name, default=None):
    if isinstance(item, dict):
        return item.get(name, default)
    return getattr(item, name, default)
