import unittest

import chat_rendering


class ChatRenderingTests(unittest.TestCase):
    def test_render_message_images_escapes_metadata_and_renders_preview(self):
        html = chat_rendering.render_message_images(
            [
                {
                    "filename": '<photo "one".png>',
                    "mime_type": "image/png",
                    "size": 12,
                    "data_url": 'data:image/png;base64,aW1n"',
                }
            ]
        )

        self.assertIn("&lt;photo &quot;one&quot;.png&gt;", html)
        self.assertIn('src="data:image/png;base64,aW1n&quot;"', html)
        self.assertIn("12 B", html)
        self.assertIn("image-preview", html)

    def test_append_loading_indicator_adds_dots_to_same_paragraph(self):
        html = chat_rendering.append_loading_indicator("<p>Sending prompt</p>")

        self.assertEqual(html.count("loading-indicator"), 1)
        self.assertEqual(html.count("dot"), 3)
        self.assertIn("Sending prompt<span class=\"loading-indicator\">", html)


if __name__ == "__main__":
    unittest.main()
