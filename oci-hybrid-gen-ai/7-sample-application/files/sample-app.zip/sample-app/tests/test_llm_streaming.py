import unittest
from types import SimpleNamespace

import llm


class FakeResponses:
    def __init__(self, created_response=None):
        self.created_response = created_response
        self.created_options = None

    def create(self, **kwargs):
        self.created_options = kwargs
        return self.created_response


class FakeClient:
    def __init__(self, responses):
        self.responses = responses
        self.conversations = FakeConversations()


class FakeConversations:
    def __init__(self, conversation_id="conv_1"):
        self.conversation_id = conversation_id
        self.create_calls = 0

    def create(self):
        self.create_calls += 1
        return SimpleNamespace(id=self.conversation_id)


def response(text, output_text="", status="completed"):
    return SimpleNamespace(
        status=status,
        output_text=output_text,
        output=[SimpleNamespace(content=[SimpleNamespace(text=text)])],
    )


class StreamingTests(unittest.TestCase):
    def setUp(self):
        self.cfg = {"max_output_tokens": 1000}
        self.original_sleep = llm.time.sleep
        llm.time.sleep = lambda _seconds: None

    def tearDown(self):
        llm.time.sleep = self.original_sleep

    def test_response_text_prefers_full_output_over_short_output_text(self):
        text = llm.response_text(
            response(
                "The acronym LLM stands for large language model.",
                output_text="The acronym",
            )
        )

        self.assertEqual(text, "The acronym LLM stands for large language model.")

    def test_stream_response_uses_full_response_text(self):
        responses = FakeResponses(
            created_response=response(
                "The acronym LLM stands for large language model.",
                output_text="The acronym",
            )
        )
        client = FakeClient(responses)

        chunks = list(
            llm.stream_response(
                client,
                "model",
                "what is an LLM?",
                self.cfg,
                conversation_id="conv_1",
            )
        )

        self.assertEqual(chunks[-1], "The acronym LLM stands for large language model.")

    def test_create_conversation_returns_conversation_id(self):
        client = FakeClient(FakeResponses())

        conversation_id = llm.create_conversation(client)

        self.assertEqual(conversation_id, "conv_1")
        self.assertEqual(client.conversations.create_calls, 1)

    def test_response_options_requires_conversation_id(self):
        messages = [
            {"role": "user", "content": "What is a LLM?"},
            {"role": "assistant", "content": "A LLM is a large language model."},
            {"role": "error", "content": "Error messages are not sent back."},
        ]

        with self.assertRaisesRegex(ValueError, "conversation_id is required"):
            llm.response_options("model", "Can you expand?", self.cfg, messages)

    def test_response_options_use_latest_turn_with_conversation(self):
        messages = [
            {"role": "user", "content": "What is a LLM?"},
            {"role": "assistant", "content": "A LLM is a large language model."},
            {"role": "user", "content": "Can you expand?"},
        ]

        options = llm.response_options(
            "model",
            "Can you expand?",
            self.cfg,
            messages,
            conversation_id="conv_1",
        )

        self.assertEqual(options["conversation"], "conv_1")
        self.assertEqual(
            options["input"],
            [{"role": "user", "content": "Can you expand?"}],
        )

    def test_response_options_use_latest_image_turn_with_conversation(self):
        messages = [
            {"role": "user", "content": "Earlier question"},
            {"role": "assistant", "content": "Earlier answer"},
            {
                "role": "user",
                "content": "What is shown in this image?",
                "images": [
                    {
                        "filename": "photo.png",
                        "mime_type": "image/png",
                        "size": 1234,
                        "data_url": "data:image/png;base64,aW1hZ2U=",
                    }
                ],
            },
        ]

        options = llm.response_options(
            "model",
            "What is shown in this image?",
            self.cfg,
            messages,
            conversation_id="conv_1",
        )

        self.assertEqual(
            options["input"],
            [
                {
                    "role": "user",
                    "content": [
                        {"type": "input_text", "text": "What is shown in this image?"},
                        {
                            "type": "input_image",
                            "image_url": "data:image/png;base64,aW1hZ2U=",
                        },
                    ],
                }
            ],
        )

    def test_latest_response_input_formats_attached_image_parts(self):
        messages = [
            {
                "role": "user",
                "content": "What is shown in this image?",
                "images": [
                    {
                        "filename": "photo.png",
                        "mime_type": "image/png",
                        "size": 1234,
                        "data_url": "data:image/png;base64,aW1hZ2U=",
                    }
                ],
            }
        ]

        response_input = llm.latest_response_input(
            messages,
            "What is shown in this image?",
        )

        self.assertEqual(
            response_input,
            [
                {
                    "role": "user",
                    "content": [
                        {"type": "input_text", "text": "What is shown in this image?"},
                        {
                            "type": "input_image",
                            "image_url": "data:image/png;base64,aW1hZ2U=",
                        },
                    ],
                }
            ],
        )

    def test_latest_response_input_omits_prior_image_for_followup(self):
        messages = [
            {
                "role": "user",
                "content": "What is shown in this image?",
                "images": [
                    {
                        "filename": "photo.png",
                        "mime_type": "image/png",
                        "size": 1234,
                        "data_url": "data:image/png;base64,aW1hZ2U=",
                    }
                ],
            },
            {"role": "assistant", "content": "It shows a dashboard warning light."},
            {"role": "user", "content": "What should I check first?"},
        ]

        response_input = llm.latest_response_input(
            messages,
            "What should I check first?",
        )

        self.assertEqual(
            response_input,
            [
                {"role": "user", "content": "What should I check first?"},
            ],
        )

    def test_latest_response_input_uses_prompt_when_matching_message_is_absent(self):
        response_input = llm.latest_response_input([], "Can you expand?")

        self.assertEqual(
            response_input,
            [
                {"role": "user", "content": "Can you expand?"},
            ],
        )

    def test_response_options_reject_known_text_only_model_with_images(self):
        messages = [
            {
                "role": "user",
                "content": "What is shown?",
                "images": [{"data_url": "data:image/png;base64,aW1hZ2U="}],
            }
        ]

        with self.assertRaisesRegex(ValueError, "does not support image input"):
            llm.response_options(
                "openai.gpt-oss-120b",
                "What is shown?",
                self.cfg,
                messages,
                conversation_id="conv_1",
            )

    def test_response_options_reject_known_text_only_model_with_images_before_conversation_check(self):
        messages = [
            {
                "role": "user",
                "content": "What is shown?",
                "images": [{"data_url": "data:image/png;base64,aW1hZ2U="}],
            }
        ]

        with self.assertRaisesRegex(ValueError, "does not support image input"):
            llm.response_options("openai.gpt-oss-120b", "What is shown?", self.cfg, messages)

    def test_response_options_allows_text_only_model_when_only_prior_message_has_images(self):
        messages = [
            {
                "role": "user",
                "content": "What is shown?",
                "images": [{"data_url": "data:image/png;base64,aW1hZ2U="}],
            },
            {"role": "assistant", "content": "It shows a dashboard warning light."},
            {"role": "user", "content": "What should I check first?"},
        ]

        options = llm.response_options(
            "openai.gpt-oss-120b",
            "What should I check first?",
            self.cfg,
            messages,
            conversation_id="conv_1",
        )

        self.assertEqual(options["model"], "openai.gpt-oss-120b")
        self.assertEqual(
            options["input"],
            [{"role": "user", "content": "What should I check first?"}],
        )

    def test_latest_response_input_uses_latest_matching_turn(self):
        messages = [
            {"role": "user", "content": "What should I check first?"},
            {"role": "assistant", "content": "Check tire pressure."},
            {
                "role": "user",
                "content": "What should I check first?",
                "images": [{"data_url": "data:image/png;base64,aW1hZ2U="}],
            },
        ]

        response_input = llm.latest_response_input(messages, "What should I check first?")

        self.assertEqual(
            response_input[0]["content"],
            [
                {"type": "input_text", "text": "What should I check first?"},
                {
                    "type": "input_image",
                    "image_url": "data:image/png;base64,aW1hZ2U=",
                },
            ],
        )


if __name__ == "__main__":
    unittest.main()
