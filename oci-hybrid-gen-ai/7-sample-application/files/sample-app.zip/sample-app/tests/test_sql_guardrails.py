import unittest

from sql_guardrails import (
    SqlGuardrailError,
    validate_customer_scope,
    validate_read_only_sql,
)


class SqlGuardrailTests(unittest.TestCase):
    def test_allows_select_and_strips_trailing_semicolon(self):
        self.assertEqual(validate_read_only_sql(" select * from vehicles; "), "select * from vehicles")

    def test_allows_with_query(self):
        sql = "WITH latest AS (SELECT * FROM service_orders) SELECT * FROM latest"

        self.assertEqual(validate_read_only_sql(sql), sql)

    def test_rejects_write_keyword(self):
        with self.assertRaises(SqlGuardrailError):
            validate_read_only_sql("DELETE FROM service_orders")

    def test_rejects_multiple_statements(self):
        with self.assertRaises(SqlGuardrailError):
            validate_read_only_sql("SELECT * FROM vehicles; SELECT * FROM customers")

    def test_customer_scope_allows_matching_customer_id_filter(self):
        sql = "SELECT * FROM vehicles WHERE customer_id = 7"

        self.assertEqual(validate_customer_scope(sql, 7), sql)

    def test_customer_scope_allows_matching_customer_id_in_filter(self):
        sql = "SELECT * FROM vehicles WHERE CUSTOMER_ID IN ('7')"

        self.assertEqual(validate_customer_scope(sql, 7), sql)

    def test_customer_scope_rejects_missing_customer_id_filter(self):
        with self.assertRaises(SqlGuardrailError):
            validate_customer_scope("SELECT * FROM vehicles", 7)

    def test_customer_scope_rejects_different_customer_id_filter(self):
        with self.assertRaises(SqlGuardrailError):
            validate_customer_scope("SELECT * FROM vehicles WHERE customer_id = 8", 7)

    def test_customer_scope_rejects_or_that_can_widen_results(self):
        with self.assertRaises(SqlGuardrailError):
            validate_customer_scope(
                "SELECT * FROM vehicles WHERE customer_id = 7 OR customer_id = 8",
                7,
            )

    def test_customer_scope_rejects_union_that_can_widen_results(self):
        with self.assertRaises(SqlGuardrailError):
            validate_customer_scope(
                "SELECT * FROM vehicles WHERE customer_id = 7 "
                "UNION SELECT * FROM vehicles",
                7,
            )


if __name__ == "__main__":
    unittest.main()
