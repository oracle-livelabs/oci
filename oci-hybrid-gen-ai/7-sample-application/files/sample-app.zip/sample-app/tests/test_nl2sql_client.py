import json
import unittest
from types import SimpleNamespace

from nl2sql_client import Nl2SqlClient, extract_generated_sql


class FakeClient:
    def __init__(self, data):
        self.data = data
        self.calls = []

    def call_api(self, **kwargs):
        self.calls.append(kwargs)
        return SimpleNamespace(
            data=json.dumps(self.data),
            headers={"opc-request-id": "request-id"},
        )


class Nl2SqlClientTests(unittest.TestCase):
    def test_generate_sql_posts_expected_path_and_body(self):
        fake_client = FakeClient({"jobOutput": {"content": "SELECT * FROM VEHICLES"}})
        client = Nl2SqlClient(
            "us-chicago-1",
            "20260325",
            "semantic-store",
            auth=None,
            client=fake_client,
        )

        result = client.generate_sql("show vehicles")

        self.assertEqual(result.status, "ok")
        self.assertEqual(result.sql, "SELECT * FROM VEHICLES")
        self.assertEqual(result.request_id, "request-id")
        call = fake_client.calls[0]
        self.assertEqual(
            call["resource_path"],
            "/20260325/semanticStores/semantic-store/actions/generateSqlFromNl",
        )
        self.assertEqual(call["method"], "POST")
        self.assertEqual(call["body"]["inputNaturalLanguageQuery"], "show vehicles")

    def test_generate_sql_returns_not_answerable_without_sql(self):
        client = Nl2SqlClient("region", "version", "store", auth=None, client=FakeClient({}))

        result = client.generate_sql("question")

        self.assertEqual(result.status, "not_answerable")
        self.assertEqual(result.sql, "")

    def test_extract_generated_sql_from_job_output_content(self):
        data = {
            "jobOutput": {
                "jobOutputLocation": "INLINE",
                "content": "SELECT 1 FROM dual",
            }
        }

        self.assertEqual(extract_generated_sql(data), "SELECT 1 FROM dual")


if __name__ == "__main__":
    unittest.main()
