from dataclasses import dataclass

from oci.generative_ai_inference import GenerativeAiInferenceClient
from oci.generative_ai_inference.models import (
    ApplyGuardrailsDetails,
    GuardrailConfigs,
    GuardrailsTextInput,
    PromptInjectionConfiguration,
)

from oci_iam_auth import make_iam_auth


DEFAULT_LANGUAGE_CODE = "en"
DEFAULT_PROMPT_INJECTION_THRESHOLD = 1.0
BLOCKED_MESSAGE = "Blocked by OCI ApplyGuardrails: prompt injection risk detected."


class PromptInjectionGuardrailError(RuntimeError):
    pass


@dataclass(frozen=True)
class PromptInjectionCheck:
    blocked: bool
    score: float
    message: str = ""


def check_prompt_injection(prompt, cfg, client=None):
    compartment_id = (cfg.get("guardrails_compartment_ocid") or "").strip()
    if not compartment_id:
        raise PromptInjectionGuardrailError(
            "Missing OCI ApplyGuardrails configuration: "
            "OCI_GENAI_GUARDRAILS_COMPARTMENT_OCID"
        )

    threshold = cfg.get(
        "guardrails_prompt_injection_threshold",
        DEFAULT_PROMPT_INJECTION_THRESHOLD,
    )
    try:
        threshold = float(threshold)
        response = (client or make_guardrails_client(cfg)).apply_guardrails(
            ApplyGuardrailsDetails(
                input=GuardrailsTextInput(
                    content=prompt,
                    language_code=cfg.get(
                        "guardrails_language_code",
                        DEFAULT_LANGUAGE_CODE,
                    )
                    or DEFAULT_LANGUAGE_CODE,
                ),
                guardrail_configs=GuardrailConfigs(
                    prompt_injection_config=PromptInjectionConfiguration(),
                ),
                compartment_id=compartment_id,
            )
        )
    except PromptInjectionGuardrailError:
        raise
    except Exception as exc:
        raise PromptInjectionGuardrailError(
            f"OCI ApplyGuardrails prompt injection check failed: {exc}"
        ) from exc

    score = prompt_injection_score(response)
    blocked = score >= threshold
    return PromptInjectionCheck(
        blocked=blocked,
        score=score,
        message=BLOCKED_MESSAGE if blocked else "",
    )


def make_guardrails_client(cfg):
    region = cfg.get("region") or ""
    if not region:
        raise PromptInjectionGuardrailError(
            "Missing OCI ApplyGuardrails configuration: OCI_GENAI_REGION"
        )

    auth = make_iam_auth(
        cfg.get("oci_config_file"),
        cfg.get("oci_config_profile"),
        region,
    )
    return GenerativeAiInferenceClient(
        auth.config,
        signer=auth.signer,
        service_endpoint=f"https://inference.generativeai.{region}.oci.oraclecloud.com",
    )


def prompt_injection_score(response):
    data = getattr(response, "data", response)
    results = value(data, "results")
    prompt_injection = value(results, "prompt_injection")
    score = value(prompt_injection, "score", 0.0)
    if score in (None, ""):
        return 0.0
    return float(score)


def value(item, name, default=None):
    if isinstance(item, dict):
        return item.get(name, default)
    return getattr(item, name, default)
