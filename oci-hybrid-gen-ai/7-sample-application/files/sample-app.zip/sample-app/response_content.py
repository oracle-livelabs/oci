def latest_response_input(messages, prompt):
    message = latest_user_message(messages, prompt)
    if not message:
        return [{"role": "user", "content": prompt}]
    return [{"role": "user", "content": response_message_content(message)}]


def latest_user_message(messages, prompt):
    for message in reversed(messages or []):
        if message.get("role") != "user":
            continue
        if message.get("content", "") == prompt:
            return message
        break
    return None


def response_message_content(message):
    content = message.get("content", "")
    images = message.get("images") or []
    if message.get("role") != "user" or not images:
        return content

    parts = [{"type": "input_text", "text": content}]
    for image_ref in images:
        image_url = value(image_ref, "data_url", "")
        if image_url:
            parts.append({"type": "input_image", "image_url": image_url})

    return parts if len(parts) > 1 else content


def messages_include_images(messages):
    return any(message.get("images") for message in messages or [])


def value(item, name, default=None):
    if isinstance(item, dict):
        return item.get(name, default)
    return getattr(item, name, default)
