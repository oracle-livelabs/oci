from dataclasses import dataclass
from pathlib import Path

import oci


class IamAuthError(RuntimeError):
    pass


@dataclass
class OciIamAuth:
    config: dict
    signer: object


DEFAULT_OCI_CONFIG_FILE = "~/.oci/config"
DEFAULT_OCI_CONFIG_PROFILE = "DEFAULT"


def make_iam_auth(
    config_file=DEFAULT_OCI_CONFIG_FILE,
    profile_name=DEFAULT_OCI_CONFIG_PROFILE,
    region="",
):
    try:
        config = oci.config.from_file(_expanded(config_file), profile_name)
        if region:
            config["region"] = region
        if config.get("key_file"):
            config["key_file"] = _expanded(config["key_file"])
        oci.config.validate_config(config)
        signer = oci.signer.Signer(
            tenancy=config["tenancy"],
            user=config["user"],
            fingerprint=config["fingerprint"],
            private_key_file_location=config.get("key_file"),
            pass_phrase=oci.config.get_config_value_or_default(config, "pass_phrase"),
            private_key_content=config.get("key_content"),
        )
    except Exception as exc:
        raise IamAuthError(
            f"Unable to create OCI API key signer from profile {profile_name!r}: {exc}"
        ) from exc

    return OciIamAuth(config, signer)


def _expanded(path):
    return str(Path(path or DEFAULT_OCI_CONFIG_FILE).expanduser())
