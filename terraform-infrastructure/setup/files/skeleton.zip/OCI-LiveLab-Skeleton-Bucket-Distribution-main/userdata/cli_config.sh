#!/bin/bash
# sudo curl -L -O https://raw.githubusercontent.com/oracle/oci-cli/master/scripts/install/install.sh && sudo chmod a+x install.sh && sudo ./install.sh --accept-all-defaults
curl -L -O https://raw.githubusercontent.com/oracle/oci-cli/master/scripts/install/install.sh && chmod a+x install.sh && ./install.sh --accept-all-defaults

echo "[DEFAULT]" >> ~/.oci/config
echo "user="${user_id} >> ~/.oci/config
echo "tenancy="${tenancy} >> ~/.oci/config
echo "fingerprint="${fingerprint} >> ~/.oci/config
echo "key_file=$HOME/.oci/oci_api_key.pem" >> ~/.oci/config
echo "region="${region} >> ~/.oci/config
