#########################################################
# Variables exposed to the Resource Manager UI via schema.yaml
#########################################################

variable "tenancy_ocid" {
  description = "Tenancy OCID (auto-injected by Resource Manager)"
  type        = string
}

variable "region" {
  description = "Region where resources will be deployed"
  type        = string
  default     = "eu-frankfurt-1"
}

variable "compartment_id" {
  description = "Compartment OCID where resources will be created"
  type        = string
}

# ---- VCN / Subnet CIDRs (overridable from the UI) ----

variable "vcn_cidr" {
  description = "CIDR block for the VCN"
  type        = string
  default     = "172.16.0.0/24"
}

variable "vcn_dns_label" {
  description = "DNS label for the VCN"
  type        = string
  default     = "vcn"
}

variable "management_subnet_cidr" {
  description = "CIDR block for the Management subnet (public)"
  type        = string
  default     = "172.16.0.0/28"
}

variable "untrust_subnet_cidr" {
  description = "CIDR block for the Untrust subnet (public)"
  type        = string
  default     = "172.16.0.16/28"
}

variable "trust_subnet_cidr" {
  description = "CIDR block for the Trust subnet (private)"
  type        = string
  default     = "172.16.0.32/28"
}

variable "environment_tag" {
  description = "Environment freeform tag value"
  type        = string
  default     = "Test"
}
