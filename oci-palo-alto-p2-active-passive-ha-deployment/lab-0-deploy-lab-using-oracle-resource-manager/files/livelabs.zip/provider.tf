#########################################################
# Author: Iwan Hoogendoorn
# Title:  Routing diagram - PART 1 - Deploy Palo Alto NGFW inside OCI
# Version: V1 (ORM Stack)
# Date:   Monday, January 26th 2026
#########################################################

terraform {
  required_version = ">= 1.2.0"

  required_providers {
    oci = {
      source  = "oracle/oci"
      version = ">= 5.0.0"
    }
  }
}

# Inside Resource Manager, authentication is injected by the
# stack automatically. No tenancy/user/fingerprint/key needed.
provider "oci" {
  region = var.region
}
