# Routing Diagram - PART 1 - Palo Alto NGFW in OCI (ORM Stack)

Oracle Resource Manager stack that deploys the base networking layer for a
Palo Alto NGFW in OCI.

## What it deploys

- 1 x VCN (default `172.16.0.0/24`)
- 1 x Internet Gateway
- 3 x Subnets:
  - `Management_Subnet` — public, `/28`
  - `Untrust_Subnet`    — public, `/28`
  - `Trust_Subnet`      — private, `/28`
- 3 x Route Tables (one per subnet; Management RT has a default route to the IGW)
- 3 x Security Lists (one per subnet)

## How to use

1. In the OCI Console: **Developer Services → Resource Manager → Stacks → Create Stack**.
2. Choose **My Configuration**, upload this zip.
3. Pick the target compartment and region, tweak the CIDRs/tag if you want.
4. **Plan → Apply**.

## Files

| File                  | Purpose                                              |
|-----------------------|------------------------------------------------------|
| `provider.tf`         | Provider config (auth injected by ORM)               |
| `variables.tf`        | Input variables                                      |
| `routing-diagram.tf`  | VCN, IGW, subnets, route tables, security lists      |
| `schema.yaml`         | UI schema for the Resource Manager form              |

## Notes

- All security lists currently allow all traffic except the Management SL which
  only allows TCP/22 and TCP/443 inbound. Tighten before using in production.
- The Trust subnet has `prohibit_public_ip_on_vnic = true` (private).
- Region default is `eu-frankfurt-1`.

---
Author: Iwan Hoogendoorn
Version: V1 (ORM Stack)
Date: Monday, January 26th 2026
