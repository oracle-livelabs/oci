#########################################################
# Author: Iwan Hoogendoorn
# Title:  Routing diagram - PART 1 - Deploy Palo Alto NGFW inside OCI
# Version: V1 (ORM Stack)
# Date:   Monday, January 26th 2026
#########################################################

#--------------------------------------------
# 1 x VCN
#--------------------------------------------

resource "oci_core_vcn" "VCN" {
  cidr_block     = var.vcn_cidr
  display_name   = "VCN"
  compartment_id = var.compartment_id
  dns_label      = var.vcn_dns_label
  freeform_tags  = { Environment = var.environment_tag }
}

#--------------------------------------------
# 1 x Internet Gateway (inside VCN)
#--------------------------------------------

resource "oci_core_internet_gateway" "igw" {
  compartment_id = var.compartment_id
  vcn_id         = oci_core_vcn.VCN.id
  display_name   = "IGW"
  enabled        = true
}

#--------------------------------------------
# 3 x Subnets (inside VCN)
#--------------------------------------------

resource "oci_core_subnet" "Management_Subnet" {
  compartment_id             = var.compartment_id
  vcn_id                     = oci_core_vcn.VCN.id
  cidr_block                 = var.management_subnet_cidr
  display_name               = "Management_Subnet"
  dns_label                  = "management"
  route_table_id             = oci_core_route_table.Management_Subnet_RT.id
  security_list_ids          = [oci_core_security_list.Management_Subnet_SL.id]
  prohibit_public_ip_on_vnic = false
}

resource "oci_core_subnet" "Untrust_Subnet" {
  compartment_id             = var.compartment_id
  vcn_id                     = oci_core_vcn.VCN.id
  cidr_block                 = var.untrust_subnet_cidr
  display_name               = "Untrust_Subnet"
  dns_label                  = "untrust"
  route_table_id             = oci_core_route_table.Untrust_Subnet_RT.id
  security_list_ids          = [oci_core_security_list.Untrust_Subnet_SL.id]
  prohibit_public_ip_on_vnic = false
}

resource "oci_core_subnet" "Trust_Subnet" {
  compartment_id             = var.compartment_id
  vcn_id                     = oci_core_vcn.VCN.id
  cidr_block                 = var.trust_subnet_cidr
  display_name               = "Trust_Subnet"
  dns_label                  = "trust"
  route_table_id             = oci_core_route_table.Trust_Subnet_RT.id
  security_list_ids          = [oci_core_security_list.Trust_Subnet_SL.id]
  prohibit_public_ip_on_vnic = true
}

#--------------------------------------------
# 3 x VCN Route Tables (for Subnets)
#--------------------------------------------

resource "oci_core_route_table" "Management_Subnet_RT" {
  compartment_id = var.compartment_id
  vcn_id         = oci_core_vcn.VCN.id
  display_name   = "Management_Subnet_RT"

  route_rules {
    destination       = "0.0.0.0/0"
    destination_type  = "CIDR_BLOCK"
    network_entity_id = oci_core_internet_gateway.igw.id
  }
}

resource "oci_core_route_table" "Untrust_Subnet_RT" {
  compartment_id = var.compartment_id
  vcn_id         = oci_core_vcn.VCN.id
  display_name   = "Untrust_Subnet_RT"
}

resource "oci_core_route_table" "Trust_Subnet_RT" {
  compartment_id = var.compartment_id
  vcn_id         = oci_core_vcn.VCN.id
  display_name   = "Trust_Subnet_RT"
}

#--------------------------------------------
# 3 x Security Lists (for Subnets)
#--------------------------------------------

resource "oci_core_security_list" "Management_Subnet_SL" {
  compartment_id = var.compartment_id
  vcn_id         = oci_core_vcn.VCN.id
  display_name   = "Management_Subnet_SL"

  ingress_security_rules {
    protocol    = "6"
    source      = "0.0.0.0/0"
    source_type = "CIDR_BLOCK"

    tcp_options {
      min = 22
      max = 22
    }
  }

  ingress_security_rules {
    protocol    = "6"
    source      = "0.0.0.0/0"
    source_type = "CIDR_BLOCK"

    tcp_options {
      min = 443
      max = 443
    }
  }

  egress_security_rules {
    protocol         = "all"
    destination      = "0.0.0.0/0"
    destination_type = "CIDR_BLOCK"
  }
}

resource "oci_core_security_list" "Untrust_Subnet_SL" {
  compartment_id = var.compartment_id
  vcn_id         = oci_core_vcn.VCN.id
  display_name   = "Untrust_Subnet_SL"

  ingress_security_rules {
    protocol    = "all"
    source      = "0.0.0.0/0"
    source_type = "CIDR_BLOCK"
  }

  egress_security_rules {
    protocol         = "all"
    destination      = "0.0.0.0/0"
    destination_type = "CIDR_BLOCK"
  }
}

resource "oci_core_security_list" "Trust_Subnet_SL" {
  compartment_id = var.compartment_id
  vcn_id         = oci_core_vcn.VCN.id
  display_name   = "Trust_Subnet_SL"

  ingress_security_rules {
    protocol    = "all"
    source      = "0.0.0.0/0"
    source_type = "CIDR_BLOCK"
  }

  egress_security_rules {
    protocol         = "all"
    destination      = "0.0.0.0/0"
    destination_type = "CIDR_BLOCK"
  }
}

#--------------------------------------------
# Outputs
#--------------------------------------------

output "vcn_id" {
  description = "OCID of the created VCN"
  value       = oci_core_vcn.VCN.id
}

output "management_subnet_id" {
  description = "OCID of the Management subnet"
  value       = oci_core_subnet.Management_Subnet.id
}

output "untrust_subnet_id" {
  description = "OCID of the Untrust subnet"
  value       = oci_core_subnet.Untrust_Subnet.id
}

output "trust_subnet_id" {
  description = "OCID of the Trust subnet"
  value       = oci_core_subnet.Trust_Subnet.id
}

output "internet_gateway_id" {
  description = "OCID of the Internet Gateway"
  value       = oci_core_internet_gateway.igw.id
}
