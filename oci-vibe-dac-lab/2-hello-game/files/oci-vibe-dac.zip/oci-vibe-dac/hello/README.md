Empty directory to create the Hello World sample
