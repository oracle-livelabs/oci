# OCI Lustre + FSS Podman Cache Demo

## Overview

This stack deploys a complete OCI environment to demonstrate **container image caching and startup performance** using OCI shared storage options: FSS and Lustre File Storage.

The deployment includes:
- A VCN with public and private subnets
- An OCI File Storage Service (FSS) filesystem
- An OCI Lustre File Storage filesystem
- A Linux compute instance

The compute instance is prepared via **cloud-init** to:
- Mount FSS exports
- Install Podman and required dependencies
- Build and install the Lustre client
- Reboot once to activate the correct kernel
- Mount the Lustre filesystem
- Prepare directories for Podman image caching

A separate script allows the user to **manually benchmark Podman cold vs warm pulls and runs**, comparing FSS and Lustre as cache backends.

---

## Getting Started

### Prerequisites

- An OCI account with permissions to create:
  - Networking resources
  - Compute instances
  - File Storage Service (FSS)
  - Lustre File Storage
- Terraform installed locally
- OCI CLI (optional, for credential verification)
- An SSH key pair
- SSH access from your local machine

---

## Option: Deploy via Terraform CLI

### Prepare Configuration Files

1. Rename the provider template:
   ```
   provider.auto.tfvars.tpl → provider.auto.tfvars
   ```

2. Edit `provider.auto.tfvars` and fill in all required values:
   - `tenancy_ocid`
   - `user_ocid`
   - `fingerprint`
   - `private_key_path`
   - `region`
   - compartment OCIDs

3. Review and adjust terraform.tfvars (SSH key paths and, if needed, CIDRs, shapes, images, and storage sizes).

---

### Run Terraform

```
terraform init
terraform plan
terraform apply
```

**Note:**  
Terraform completes infrastructure provisioning first.  
The full setup continues on the instance via **cloud-init**, including:
- FSS mounting
- Podman installation
- Lustre client build
- Automatic reboot
- Lustre filesystem mount

This phase can take **30+ minutes**, mainly due to kernel changes and Lustre client build.

---

## What the Stack Creates

### Network

- One VCN
- Public and private subnets
- Internet and NAT gateways
- Route tables and security lists

---

### Storage

**File Storage Service (FSS)**  
- File system
- Mount target
- Export  
- Mount target IPs are automatically assigned by OCI and discovered at runtime

**Lustre File Storage**  
- Lustre filesystem in the private subnet  
- Full mount specification is exposed as a Terraform output

---

### Compute Instance

- Oracle Linux 9 instance
- Public IP enabled (required for SSH and provisioning)
- Cloud-init prepares the system but **does not run benchmarks**

---

## Verify Instance Preparation

After `terraform apply` completes, SSH into the instance:

```
ssh opc@<instance_public_ip>
```

### Verify FSS mount

```
mount | grep media
```

If the mount is missing, check logs:

```
sudo tail -f /var/log/cloud-init.log
sudo tail -f /var/log/cloud-init-output.log
sudo tail -f /var/log/podman-fss-ready.log
```

---

### Verify script is present

```
ls /tmp
```

You should see:
- `lustre_fss_test_script.sh`

---

### Monitor post-reboot Lustre setup

During the post-reboot phase (Lustre client build and mount), monitor:

```
sudo journalctl -u post-reboot.service -f
```

---

## Benchmark Podman Image Caching

Benchmarking is performed **manually** by the user.

The script `lustre_fss_test_script.sh` compares Podman behavior using:
- FSS-backed cache
- Lustre-backed cache

### Run the benchmark script

Interactive mode:
```
./lustre_fss_test_script.sh
```

Non-interactive examples:
```
BACKEND=fss IMAGE_PROFILE=small ./lustre_fss_test_script.sh
BACKEND=lustre IMAGE_PROFILE=large ./lustre_fss_test_script.sh
```

The script measures:
- Cold pull
- Cold run
- Warm pull
- Warm run

Results are written to:
```
/home/opc/*_test_results.log
```

---

## Cleanup

When finished, destroy the environment:

```
terraform destroy
```

---

## Notes

- SSH access and a public IP are required (SSH provisioners are used).
- The instance reboots automatically during Lustre setup.
- Lustre client build can take several minutes.
- Security lists are permissive and intended for demo purposes only.
- This stack is designed for **demonstration and benchmarking**, not production use.
