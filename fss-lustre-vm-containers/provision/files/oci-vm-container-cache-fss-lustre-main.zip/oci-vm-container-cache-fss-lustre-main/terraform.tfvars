########################### NETWORK #################################

vcn_params = {
  lustrevcn = {
    compartment_name = "sandbox"
    display_name     = "VCNTF_lustrefss"
    vcn_cidr         = "10.20.0.0/16"
    dns_label        = "vcntf"
  }
}

subnet_params = {
  lustrefsspub = {
    display_name      = "lustrefsspub"
    cidr_block        = "10.20.1.0/24"
    dns_label         = "VCNPUB"
    is_subnet_private = false
    sl_name           = "lustresl"
    rt_name           = "lustrefsspub"
    vcn_name          = "lustrevcn"
  }
  lustrefsspriv = {
    display_name      = "lustrefsspriv"
    cidr_block        = "10.20.2.0/24"
    dns_label         = "lustre1priv"
    is_subnet_private = true
    sl_name           = "lustresl"
    rt_name           = "lustrefsspriv"
    vcn_name          = "lustrevcn"
  }
}

igw_params = {
  lustreigw = {
    display_name = "VCNIGW"
    vcn_name     = "lustrevcn"
  },
}

ngw_params = {
  lustrengw = {
    display_name = "VCNNGW"
    vcn_name     = "lustrevcn"
  },
}

rt_params = {
  lustrefsspub = {
    display_name = "PUB-RT"
    vcn_name     = "lustrevcn"

    route_rules = [
      {
        destination = "0.0.0.0/0"
        use_igw     = true
        igw_name    = "lustreigw"
        ngw_name    = null
      },
    ]
  },
  lustrefsspriv = {
    display_name = "PRIV-RT"
    vcn_name     = "lustrevcn"

    route_rules = [
      {
        destination = "0.0.0.0/0"
        use_igw     = false
        igw_name    = null
        ngw_name    = "lustrengw"
      },
    ]
  },
}

sl_params = {
  lustresl = {
    vcn_name     = "lustrevcn"
    display_name = "VCN-SL"

    egress_rules = [
      {
        stateless   = "false"
        protocol    = "all"
        destination = "0.0.0.0/0"
      },
    ]

    ingress_rules = [
      {
        stateless   = "false"
        protocol    = "all"
        source      = "0.0.0.0/0"
        source_type = "CIDR_BLOCK"
        tcp_options = []
        udp_options = []
      },
    ]
  }
}

############################## COMPUTE ##################################

linux_images = {
  eu-frankfurt-1 = {
    oel9    = "ocid1.image.oc1.eu-frankfurt-1.aaaaaaaap6fyk44edftzyywudj4ofztrjsq7d47qtslsd74rlzlm3hu52xca" #Oracle-Linux-9.6-2025.11.20-0
  }
  us-ashburn-1 = {
    oel9    = "ocid1.image.oc1.iad.aaaaaaaaglxne5nh73mxqppl3fkzkqdlda3k22y6oyxcvy6gcaxxsym54mca"
  }
}

instance_params = {
  lustrefssvm = {
    ad                   = 1
    shape                = "VM.Standard.E5.Flex"
    hostname             = "lustrefssvm"
    boot_volume_size     = 50
    preserve_boot_volume = false
    assign_public_ip     = true
    compartment_name     = "sandbox"
    subnet_name          = "lustrefsspub"
    freeform_tags = {
      "client" : "vfo",
      "department" : "vfo"
    }
    block_vol_att_type = "iscsi"
    encrypt_in_transit = true
    fd                 = 1
    script_name        = "lustre_fss_test_script.sh"
    image_version      = "oel9"
    ssh_private_key    = "$HOME/.ssh/id_rsa" ## PATH TO SSH PRIVATE KEY - CHNAGE ME
    script_tf_string   = "TEST_HUR_1"
    ocpus               = 1
    memory_in_gbs       = 16
    fss_mounts = [
      {
        mount_target_name = "mt0"
        export_path       = "/media"
        mount_point       = "/mnt/media"
        nfs_opts          = "defaults,_netdev"
      },
    ]
  }
}

ssh_public_key = "$HOME/.ssh/id_rsa.pub" ## PATH TO SSH PUBLIC KEY - CHANGE ME

########################### FSS ###############################

fss_params = {
  fss1 = {
    ad               = 1
    compartment_name = "sandbox"
    name             = "fss1"
    kms_key_name     = ""
  }
}

mt_params = {
  mt0 = {
    ad               = 1
    compartment_name = "sandbox"
    name             = "mt0"
    subnet_name      = "lustrefsspub"
  }
}

export_params = {
  mt1 = {
    export_set_name = "mt0"
    filesystem_name = "fss1"
    path            = "/media"

    export_options = [
      {
        source = "10.20.0.0/16"
        access   = "READ_WRITE"
        identity = "NONE"
        use_port = true
      },
    ]
  }
}

kms_key_ids = {}

################ LUSTRE #################

lustre_params = {
  lustrefs = {
    ad                  = 1
    compartment_name = "sandbox"
    name             = "lustrefs"
    capacity_in_gbs     = 31200 #31.2 TB
    subnet_name      = "lustrefsspriv"
    performance_tier = "MBPS_PER_TB_125"
    identity_squash  = "NONE"
    display_name     = "lustre-test"
  }
}
