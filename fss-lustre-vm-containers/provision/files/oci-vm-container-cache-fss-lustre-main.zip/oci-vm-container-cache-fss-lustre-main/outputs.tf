output "vcns" {
  value = module.network.vcns
}

output "subnets" {
  value = module.network.subnets
}

output "linux_instances" {
  value = module.compute.linux_instances
}

# output "filesystems" {
#   value = module.fss.filesystems
# }

# output "mount_targets" {
#   value = module.fss.mount_targets
# }

output "lustre_filesystems" {
  value = module.lustre-storage.lustre_mount
}

