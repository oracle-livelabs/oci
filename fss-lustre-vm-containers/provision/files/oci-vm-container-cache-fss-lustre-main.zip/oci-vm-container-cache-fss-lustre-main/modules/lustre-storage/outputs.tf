output "lustre_mount" {
  value = {
    for fs in oci_lustre_file_storage_lustre_file_system.this :
    fs.display_name => {
      id                        = fs.id
      management_service_addr   = fs.management_service_address
      lnet                      = fs.lnet
      file_system_name          = fs.file_system_name
      mount_spec                = "${fs.management_service_address}@${fs.lnet}:/${fs.file_system_name}"
    }
  }
}
