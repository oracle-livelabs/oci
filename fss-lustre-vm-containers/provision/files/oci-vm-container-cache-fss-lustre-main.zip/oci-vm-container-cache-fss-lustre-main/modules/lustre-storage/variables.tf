variable "compartment_ids" {
  type = map(string)
}

variable "subnet_ids" {
  type = map(string)
}

variable "lustre_params" {
  type = map(object({
    ad               = number
    compartment_name = string
    name             = string
    subnet_name      = string
    capacity_in_gbs  = number
    performance_tier = string
    identity_squash  = string
    display_name     = string
  }))
}