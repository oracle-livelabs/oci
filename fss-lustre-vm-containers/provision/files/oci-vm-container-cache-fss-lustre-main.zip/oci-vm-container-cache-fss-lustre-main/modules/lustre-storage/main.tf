data "oci_identity_availability_domains" "ads" {
  compartment_id = var.compartment_ids[var.lustre_params[keys(var.lustre_params)[0]].compartment_name]
}

resource "oci_lustre_file_storage_lustre_file_system" "this" {
  for_each = var.lustre_params
  availability_domain = data.oci_identity_availability_domains.ads.availability_domains[each.value.ad - 1].name    #"RiYU:EU-FRANKFURT-1-AD-1"
  capacity_in_gbs     = each.value.capacity_in_gbs
  compartment_id      = var.compartment_ids[each.value.compartment_name]
  file_system_name    = each.value.name
  performance_tier    = each.value.performance_tier
  subnet_id           = var.subnet_ids[each.value.subnet_name]
  root_squash_configuration {
    identity_squash = each.value.identity_squash
  }
  freeform_tags = {
    Department = "Finance"
  }

  display_name = each.value.display_name
}
