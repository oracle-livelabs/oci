#!/bin/bash

LOGFILE=""
SKIP_PAUSE=${SKIP_PAUSE:-0}

# Backend selection:
# - Interactive (asks you):      ./script.sh
# - Non-interactive (no prompt): BACKEND=fss ./script.sh
#                               BACKEND=lustre ./script.sh
BACKEND=${BACKEND:-""}

if [ -z "$BACKEND" ]; then
  echo "Select backend for cache:"
  echo "  1) FSS    (mounted at /mnt/media)"
  echo "  2) Lustre (mounted at /mnt/gs-lfs)"
  read -r -p "Choose [1-2]: " choice
  case "$choice" in
    1) BACKEND="fss" ;;
    2) BACKEND="lustre" ;;
    *) echo "Invalid choice"; exit 1 ;;
  esac
fi

case "$BACKEND" in
  fss)    CACHE_ROOT="/mnt/media/podman-store" ;;
  lustre) CACHE_ROOT="/mnt/gs-lfs/podman-store" ;;
  *) echo "Unknown BACKEND=$BACKEND"; exit 1 ;;
esac

# Image selection:
# - Interactive:                 ./script.sh
# - Non-interactive:             IMAGE_PROFILE=small|medium|large ./script.sh
IMAGE_PROFILE=${IMAGE_PROFILE:-""}

if [ -z "$IMAGE_PROFILE" ]; then
  echo "Select image profile:"
  echo "  1) small  = docker.io/library/alpine:latest"
  echo "  2) medium = docker.io/library/debian:bookworm-slim"
  echo "  3) large  = docker.io/library/python:3.12"
  read -r -p "Choose [1-3]: " img_choice
  case "$img_choice" in
    1) IMAGE_PROFILE="small" ;;
    2) IMAGE_PROFILE="medium" ;;
    3) IMAGE_PROFILE="large" ;;
    *) echo "Invalid choice"; exit 1 ;;
  esac
fi

case "$IMAGE_PROFILE" in
  small)  IMAGE="docker.io/library/alpine:latest" ;;
  medium) IMAGE="docker.io/library/debian:bookworm-slim" ;;
  large)  IMAGE="docker.io/library/python:3.12" ;;
  *) echo "Unknown IMAGE_PROFILE=$IMAGE_PROFILE"; exit 1 ;;
esac

LOGFILE="/home/opc/${IMAGE_PROFILE}_${BACKEND}_test_results.log"

pause() {
  [ "$SKIP_PAUSE" -eq 1 ] && return 0
  read -r -p ">>> Press Enter to continue (or 'q' to quit): " ans
  [ "$ans" = "q" ] && echo "Aborted." && exit 0
}

echo "===== ${BACKEND^^} Podman Cache Timing =====" | sudo tee "$LOGFILE"
echo "Image: $IMAGE" | sudo tee -a "$LOGFILE"
echo "Test started: $(date)" | sudo tee -a "$LOGFILE"

# STEP 0: base config
echo "[Step 0] Setting base Podman storage configuration (driver=overlay)" | sudo tee -a "$LOGFILE"
sudo tee /etc/containers/storage.conf >/dev/null <<EOF
[storage]
driver = "overlay"
runroot = "/run/containers/storage"
graphroot = "/var/lib/containers/storage"
[storage.options.overlay]
mount_program = "/usr/bin/fuse-overlayfs"
EOF

sudo mkdir -p /var/lib/containers/storage "$CACHE_ROOT"

if [ "$BACKEND" = "lustre" ]; then
  sudo chown -R root:root "$CACHE_ROOT"
  sudo chmod 755 "$CACHE_ROOT"
fi
sudo podman system migrate >/dev/null 2>&1 || true
pause

# STEP 1: true cold baseline
echo "[Step 1] True cold environment (no cache, clean start)" | sudo tee -a "$LOGFILE"
sudo systemctl stop podman.socket podman.service 2>/dev/null || true
sudo podman system reset -f >/dev/null 2>&1
sudo podman rmi -a -f >/dev/null 2>&1 || true
sudo rm -rf /var/lib/containers /run/containers /home/opc/.local/share/containers "$CACHE_ROOT"/* >/dev/null 2>&1
sudo mkdir -p /var/lib/containers/storage "$CACHE_ROOT"
sudo podman system migrate >/dev/null 2>&1 || true
pause

echo "[Step 1a] Cold pull (true network download, no cache)" | sudo tee -a "$LOGFILE"
TIMEFORMAT=$'[Cold Pull] real %3R user %3U sys %3S'
{ time sudo podman pull "$IMAGE" >/dev/null 2>&1; } 2>&1 | sudo tee -a "$LOGFILE"
echo "[Snapshot A] LOCAL ONLY expected" | sudo tee -a "$LOGFILE"
sudo podman images --format '{{.Repository}}:{{.Tag}}\t{{.ID}}\tRO={{.ReadOnly}}' | sudo tee -a "$LOGFILE"
pause

echo "[Step 1b] Cold run (force download during run; fresh env)" | sudo tee -a "$LOGFILE"
sudo podman system reset -f >/dev/null 2>&1
sudo rm -rf /var/lib/containers/storage/* >/dev/null 2>&1
sudo mkdir -p /var/lib/containers/storage
sudo podman system migrate >/dev/null 2>&1 || true
TIMEFORMAT=$'[Cold Run]  real %3R user %3U sys %3S'
{ time sudo podman run --pull=always --rm "$IMAGE" echo "hello cold run" >/dev/null 2>&1; } 2>&1 | sudo tee -a "$LOGFILE"
pause

# STEP 2: copy store to shared cache
echo "[Step 2] Copying local Podman store to ${BACKEND^^} cache..." | sudo tee -a "$LOGFILE"
sudo mkdir -p "$CACHE_ROOT/full-copy"
sudo rm -rf "$CACHE_ROOT/full-copy"/*
sudo cp -a /var/lib/containers/storage/. "$CACHE_ROOT/full-copy/" || true
pause

# STEP 3: configure additionalimagestores
echo "[Step 3] Setting additionalimagestores -> ${BACKEND^^}" | sudo tee -a "$LOGFILE"
sudo tee /etc/containers/storage.conf >/dev/null <<EOF
[storage]
driver = "overlay"
runroot = "/run/containers/storage"
graphroot = "/var/lib/containers/storage"
[storage.options]
additionalimagestores = ["$CACHE_ROOT/full-copy"]
[storage.options.overlay]
mount_program = "/usr/bin/fuse-overlayfs"
EOF
sudo podman system migrate >/dev/null 2>&1 || true
echo "[Verify] GraphOptions:" | sudo tee -a "$LOGFILE"
sudo podman info --format '{{ .Store.GraphOptions }}' | sudo tee -a "$LOGFILE"
echo "[Snapshot B] BOTH LOCAL + ${BACKEND^^} expected" | sudo tee -a "$LOGFILE"
sudo podman images --format '{{.Repository}}:{{.Tag}}\t{{.ID}}\tRO={{.ReadOnly}}' | sudo tee -a "$LOGFILE"
pause

# STEP 4: warm pull (fresh node using shared cache)
echo "[Step 4] Reset to simulate fresh node (before warm pull)" | sudo tee -a "$LOGFILE"
sudo podman system reset -f >/dev/null 2>&1
sudo rm -rf /var/lib/containers/storage/* >/dev/null 2>&1
sudo mkdir -p /var/lib/containers/storage
echo "[Snapshot C] ${BACKEND^^} ONLY expected (RO=true)" | sudo tee -a "$LOGFILE"
sudo podman images --format '{{.Repository}}:{{.Tag}}\t{{.ID}}\tRO={{.ReadOnly}}' | sudo tee -a "$LOGFILE"
pause

echo "[Step 4] Warm pull (reuse ${BACKEND^^} cache; blobs should be skipped)" | sudo tee -a "$LOGFILE"
TIMEFORMAT=$'[Warm Pull] real %3R user %3U sys %3S'
{ time sudo podman pull "$IMAGE" >/dev/null 2>&1; } 2>&1 | sudo tee -a "$LOGFILE"
echo "[Snapshot D] After warm pull" | sudo tee -a "$LOGFILE"
sudo podman images --format '{{.Repository}}:{{.Tag}}\t{{.ID}}\tRO={{.ReadOnly}}' | sudo tee -a "$LOGFILE"
pause

# STEP 5: warm run (fresh node again)
echo "[Step 5] Reset to simulate fresh node (before warm run)" | sudo tee -a "$LOGFILE"
sudo podman system reset -f >/dev/null 2>&1
sudo rm -rf /var/lib/containers/storage/* >/dev/null 2>&1
sudo mkdir -p /var/lib/containers/storage
pause

echo "[Step 5] Warm run (container startup using ${BACKEND^^}-cached image)" | sudo tee -a "$LOGFILE"
TIMEFORMAT=$'[Warm Run]  real %3R user %3U sys %3S'
{ time sudo podman run --rm "$IMAGE" echo "hello warm run" >/dev/null 2>&1; } 2>&1 | sudo tee -a "$LOGFILE"
pause

echo "===== Test Completed: $(date) =====" | sudo tee -a "$LOGFILE"
echo | sudo tee -a "$LOGFILE"
cat "$LOGFILE"
