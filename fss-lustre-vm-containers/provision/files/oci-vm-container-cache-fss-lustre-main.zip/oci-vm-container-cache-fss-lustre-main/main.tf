provider "oci" {
  tenancy_ocid     = var.provider_oci.tenancy_ocid
  user_ocid        = var.provider_oci.user_ocid
  fingerprint      = var.provider_oci.fingerprint
  private_key_path = var.provider_oci.private_key_path
  region           = var.provider_oci.region
}

module "network" {
  source          = "./modules/network"
  vcn_params      = var.vcn_params
  compartment_ids = var.compartment_ids
  igw_params      = var.igw_params
  ngw_params      = var.ngw_params
  rt_params       = var.rt_params
  sl_params       = var.sl_params
  subnet_params   = var.subnet_params
}

module "fss" {
  source        = "./modules/fss"
  compartments  = var.compartment_ids
  subnets       = module.network.subnets_ids
  fss_params    = var.fss_params
  mt_params     = var.mt_params
  export_params = var.export_params
  kms_key_ids   = var.kms_key_ids
}


module "lustre-storage" {
  source          = "./modules/lustre-storage"
  compartment_ids = var.compartment_ids
  subnet_ids      = module.network.subnets_ids
  lustre_params   = var.lustre_params
}

module "compute" {
  source          = "./modules/instances"
  compartment_ids = var.compartment_ids
  subnet_ids      = module.network.subnets_ids
  instance_params = var.instance_params
  region          = var.provider_oci.region
  linux_images    = var.linux_images
  ssh_public_key  = var.ssh_public_key

  mount_targets   = module.fss.mount_targets
  lustre_mount    = module.lustre-storage.lustre_mount
}