/* Copyright (c) 2025, Oracle and/or its affiliates */

define([], () => {
  'use strict';
  
  class PageModule {
  }
    
  return PageModule;
});
  