/* Copyright (c) 2025, Oracle and/or its affiliates */

define([], function() {
  'use strict';

  class FlowModule {
  }

  return FlowModule;
});
