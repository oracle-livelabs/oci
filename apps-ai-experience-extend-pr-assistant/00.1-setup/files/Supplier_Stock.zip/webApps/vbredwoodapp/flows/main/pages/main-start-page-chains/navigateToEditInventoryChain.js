define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditInventoryChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.inventoryId
     */
    async run(context, { inventoryId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const navigateToPageMainEditInventoryResult = await Actions.navigateToPage(context, {
        page: 'main-edit-inventory',
        params: {
          inventoryId: inventoryId,
        },
      });
    }
  }

  return navigateToEditInventoryChain;
});
